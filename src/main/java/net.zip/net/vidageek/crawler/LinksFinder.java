package net.vidageek.crawler;

import java.util.List;

public interface LinksFinder {

	public List<String> getLinks();
}
