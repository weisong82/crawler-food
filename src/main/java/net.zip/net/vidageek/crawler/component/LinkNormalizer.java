/**
 * 
 */
package net.vidageek.crawler.component;

/**
 * @author jonasabreu
 * 
 */
public interface LinkNormalizer {

	String normalize(final String url);

}
